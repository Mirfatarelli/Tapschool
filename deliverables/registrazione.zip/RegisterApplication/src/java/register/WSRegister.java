/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package register;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author marelli_riccardo2
 */
@WebService(serviceName = "WSRegister")
public class WSRegister {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "register")
    public Boolean operation(@WebParam(name = "Username") String Username, @WebParam(name = "Password") String Password, @WebParam(name = "ConfirmPassword") String ConfirmPassword) {
        if(Password.equals(ConfirmPassword)){
            return true;
        }else{
            return false;
        }
        
    }
}
