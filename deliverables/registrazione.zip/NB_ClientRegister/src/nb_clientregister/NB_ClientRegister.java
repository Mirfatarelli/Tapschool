/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb_clientregister;

import java.util.Scanner;

/**
 *
 * @author marelli_riccardo2
 */
public class NB_ClientRegister {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String user="", psw="", pswconf="";
        System.out.print("Inserisci nome utente:");
        user=input.nextLine();
        System.out.print("Inserisci password:");
        psw=input.nextLine();
        System.out.print("Conferma password:");
        pswconf=input.nextLine();
        boolean fatto=register(user,psw,pswconf);
        if(fatto==true){
        System.out.println("Ti sei registrato!");
        }else{
        System.out.println("Le due password non coincidono");
        }
    }

    private static Boolean register(java.lang.String username, java.lang.String password, java.lang.String confirmPassword) {
        register.WSRegister_Service service = new register.WSRegister_Service();
        register.WSRegister port = service.getWSRegisterPort();
        return port.register(username, password, confirmPassword);
    }
    
}
