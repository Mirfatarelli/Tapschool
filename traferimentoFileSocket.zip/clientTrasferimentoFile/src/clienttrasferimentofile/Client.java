package clienttrasferimentofile;

import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
 
  private final String SERVER_HOST = "127.0.0.1";
  private final int SERVER_PORT = 9977;

  public static void main(String[] args) {
      Client c = new Client();
       Scanner input = new Scanner(System.in);
      try {
          System.out.print("Inserisci percorso file:");
          String file=input.nextLine();
          c.sendFile(new File(file));
          
      } catch (IOException e) {
          e.printStackTrace();
      }
  }
 
  private void sendFile(File file) throws IOException {
      Socket socket = null;
      try {
        
          socket = new Socket(SERVER_HOST, SERVER_PORT);
      } catch (UnknownHostException e) {
          e.printStackTrace();
      } catch (IOException e) {
          e.printStackTrace();
      }
 
      ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
      oos.reset();
      oos.writeObject(file);
      oos.flush();
      oos.close();
  }
}