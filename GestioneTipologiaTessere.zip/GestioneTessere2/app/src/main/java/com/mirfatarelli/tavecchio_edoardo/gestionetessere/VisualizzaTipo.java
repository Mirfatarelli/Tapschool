package com.mirfatarelli.tavecchio_edoardo.gestionetessere;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class VisualizzaTipo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizza_tipo);
    }
}
